$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/linking/http_401_responses.feature");
formatter.feature({
  "line": 1,
  "name": "Handle all the Doc Linking API cases that result in HTTP 401 - UNAUTHORISED",
  "description": "Reference Stories:\nXTN-4246: Implement exception handling for Authorization case",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 20,
  "name": "Validate 401 when no Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 21,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027No authorization provided\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 27,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 28,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 29,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 30,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 31,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 924669879,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 27365772,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 97809283,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 12794652,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 8114598,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 15809898,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 28156963,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 13396445,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 41284590,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Validate 401 when no Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 21,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027No authorization provided\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 59189843,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 946973549,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 2420211,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 37338751,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027No authorization provided\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 12460598,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 34554592,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 17641952,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 14847487,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 8884926,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 8830442,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 10353484,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 13806406,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9101374,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 33395276,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Validate 401 when no Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 21,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027No authorization provided\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 12121366,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 341828907,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 80263,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 26191894,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027No authorization provided\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 19689473,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 33292105,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 23796665,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 18887364,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 24501787,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 13555831,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 12734513,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 19471736,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 12320252,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 45564645,
  "status": "passed"
});
formatter.scenario({
  "line": 31,
  "name": "Validate 401 when no Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-no-authorization-header;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 21,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027No authorization provided\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 5656759,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 378454358,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 115065,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 6543988,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027No authorization provided\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 8728133,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 33,
  "name": "Validate 401 when invalid credentials provided in Basic Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 34,
  "name": "header Authorization \u003d \u0027Basic invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 38,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 41,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 42,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 43,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 44,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 45,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 51189930,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11248020,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 14799504,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 5153368,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 10616968,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11928669,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5542667,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 10061524,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 38596422,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "Validate 401 when invalid credentials provided in Basic Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 34,
  "name": "header Authorization \u003d \u0027Basic invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 38,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "\u0027Basic invalid_blah_blah\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4900810,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 6446068,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 511099348,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 74659,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 9601258,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 19192206,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 32130886,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 21370704,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 16197022,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 7791719,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5533636,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5874557,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6352476,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6125654,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 28778183,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "Validate 401 when invalid credentials provided in Basic Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 34,
  "name": "header Authorization \u003d \u0027Basic invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 38,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "\u0027Basic invalid_blah_blah\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 8975946,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 7067754,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 595831242,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 95030,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 11068928,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 11807355,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 31978008,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 14807679,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 13781927,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 13188625,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6862054,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 13483416,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3687003,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 12396979,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 23813001,
  "status": "passed"
});
formatter.scenario({
  "line": 45,
  "name": "Validate 401 when invalid credentials provided in Basic Authorization header",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-invalid-credentials-provided-in-basic-authorization-header;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 34,
  "name": "header Authorization \u003d \u0027Basic invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 38,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "\u0027Basic invalid_blah_blah\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4713097,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 4156508,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 138340371,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 84092,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 6172441,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4243773,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 47,
  "name": "Validate 401 when unsupported Authorization type provided",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 48,
  "name": "header Authorization \u003d \u0027OAuth invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 49,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 50,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 51,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 52,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 53,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Unsupported authentication type\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 55,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 56,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 57,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 58,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 59,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 20509504,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 14700155,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9298061,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 4199736,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5440125,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3495932,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3311531,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6998263,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 31289778,
  "status": "passed"
});
formatter.scenario({
  "line": 57,
  "name": "Validate 401 when unsupported Authorization type provided",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 48,
  "name": "header Authorization \u003d \u0027OAuth invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 49,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 50,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 51,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 52,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 53,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Unsupported authentication type\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "\u0027OAuth invalid_blah_blah\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4175005,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 5322449,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 362051085,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 66092,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 6029121,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Unsupported authentication type\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5490878,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 27184273,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11525088,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 16627144,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 6602380,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3543440,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3174494,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5592794,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6318732,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 40001967,
  "status": "passed"
});
formatter.scenario({
  "line": 58,
  "name": "Validate 401 when unsupported Authorization type provided",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 48,
  "name": "header Authorization \u003d \u0027OAuth invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 49,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 50,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 51,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 52,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 53,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Unsupported authentication type\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "\u0027OAuth invalid_blah_blah\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 7231816,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 6677884,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 305909370,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 80423,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5501079,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Unsupported authentication type\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5739009,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 23617269,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11048148,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 28918324,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 8765381,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 28122310,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11538171,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 16987109,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 21366380,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 43177355,
  "status": "passed"
});
formatter.scenario({
  "line": 59,
  "name": "Validate 401 when unsupported Authorization type provided",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-unsupported-authorization-type-provided;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 48,
  "name": "header Authorization \u003d \u0027OAuth invalid_blah_blah\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 49,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 50,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 51,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 52,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 53,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Unsupported authentication type\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "\u0027OAuth invalid_blah_blah\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 3865435,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 15343304,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 350134281,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 107995,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 19696300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Unsupported authentication type\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 20726762,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 61,
  "name": "Validate 401 when a User making the request is Locked",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 62,
  "name": "def locked_user \u003d call basicAuth { username: \u0027knga\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 63,
  "name": "header Authorization \u003d locked_user",
  "keyword": "And "
});
formatter.step({
  "line": 64,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 65,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 66,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 67,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 68,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 70,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 71,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 72,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 73,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 74,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 29762439,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 15334774,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 14540207,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 5092234,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4199474,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6887036,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 7681620,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5427034,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 30144925,
  "status": "passed"
});
formatter.scenario({
  "line": 72,
  "name": "Validate 401 when a User making the request is Locked",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 62,
  "name": "def locked_user \u003d call basicAuth { username: \u0027knga\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 63,
  "name": "header Authorization \u003d locked_user",
  "keyword": "And "
});
formatter.step({
  "line": 64,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 65,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 66,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 67,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 68,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "locked_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027knga\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 18
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5793580,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "locked_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4529546,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 4209895,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 317261656,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 82624,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5043586,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5585099,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 18688016,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11739714,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 12480792,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 5342255,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3351815,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3984371,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2846709,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3304237,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 29042709,
  "status": "passed"
});
formatter.scenario({
  "line": 73,
  "name": "Validate 401 when a User making the request is Locked",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 62,
  "name": "def locked_user \u003d call basicAuth { username: \u0027knga\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 63,
  "name": "header Authorization \u003d locked_user",
  "keyword": "And "
});
formatter.step({
  "line": 64,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 65,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 66,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 67,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 68,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "locked_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027knga\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 18
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 8059914,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "locked_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4327988,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 3440541,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 431357902,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 90235,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 14547109,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 6815746,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 24427965,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9816390,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 14533393,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 5623575,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3722286,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3589041,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5006140,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4616917,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 19641411,
  "status": "passed"
});
formatter.scenario({
  "line": 74,
  "name": "Validate 401 when a User making the request is Locked",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-locked;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 62,
  "name": "def locked_user \u003d call basicAuth { username: \u0027knga\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 63,
  "name": "header Authorization \u003d locked_user",
  "keyword": "And "
});
formatter.step({
  "line": 64,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 65,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 66,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 67,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 68,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "locked_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027knga\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 18
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4446363,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "locked_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4455731,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 4092268,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 317198208,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 73055,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4920059,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4198422,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 76,
  "name": "Validate 401 when a User making the request is Disabled",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 77,
  "name": "def disabled_user \u003d call basicAuth { username: \u0027bbrown\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 78,
  "name": "header Authorization \u003d disabled_user",
  "keyword": "And "
});
formatter.step({
  "line": 79,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 80,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 81,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 82,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 83,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 85,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 86,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 87,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 88,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 89,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 20313532,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 8867567,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 8909872,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 5090120,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2911010,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4007393,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2959374,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3316753,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 18749340,
  "status": "passed"
});
formatter.scenario({
  "line": 87,
  "name": "Validate 401 when a User making the request is Disabled",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 77,
  "name": "def disabled_user \u003d call basicAuth { username: \u0027bbrown\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 78,
  "name": "header Authorization \u003d disabled_user",
  "keyword": "And "
});
formatter.step({
  "line": 79,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 80,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 81,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 82,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 83,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "disabled_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027bbrown\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4860107,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "disabled_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 3140009,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 3380196,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 494806742,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 84868,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5402720,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5366279,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 16221924,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6965581,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9938355,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 4443581,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2904355,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3010237,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3041791,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 37972943,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 15773351,
  "status": "passed"
});
formatter.scenario({
  "line": 88,
  "name": "Validate 401 when a User making the request is Disabled",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 77,
  "name": "def disabled_user \u003d call basicAuth { username: \u0027bbrown\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 78,
  "name": "header Authorization \u003d disabled_user",
  "keyword": "And "
});
formatter.step({
  "line": 79,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 80,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 81,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 82,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 83,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "disabled_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027bbrown\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3600220,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "disabled_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 2500905,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 2266657,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 146224080,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 76264,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5145026,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 3124508,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 14764576,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 12908955,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 12411565,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 15089673,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4676131,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3236386,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4532818,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2738291,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 18321508,
  "status": "passed"
});
formatter.scenario({
  "line": 89,
  "name": "Validate 401 when a User making the request is Disabled",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-disabled;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 77,
  "name": "def disabled_user \u003d call basicAuth { username: \u0027bbrown\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 78,
  "name": "header Authorization \u003d disabled_user",
  "keyword": "And "
});
formatter.step({
  "line": 79,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 80,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 81,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 82,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 83,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "disabled_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027bbrown\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5716422,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "disabled_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 5596783,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 7394958,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 288705495,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 73875,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4544946,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5485560,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 91,
  "name": "Validate 401 when a User making the request is Invalid",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 92,
  "name": "def invalid_user \u003d call basicAuth { username: \u0027dummy\u0027, password: \u0027blah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 93,
  "name": "header Authorization \u003d invalid_user",
  "keyword": "And "
});
formatter.step({
  "line": 94,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 95,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 96,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 97,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 98,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 100,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 101,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 102,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 103,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 104,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 16749264,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9958783,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11599485,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 5856265,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3195031,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6520843,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5894520,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4325486,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 22153452,
  "status": "passed"
});
formatter.scenario({
  "line": 102,
  "name": "Validate 401 when a User making the request is Invalid",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 92,
  "name": "def invalid_user \u003d call basicAuth { username: \u0027dummy\u0027, password: \u0027blah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 93,
  "name": "header Authorization \u003d invalid_user",
  "keyword": "And "
});
formatter.step({
  "line": 94,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 95,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 96,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 97,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 98,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "invalid_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027dummy\u0027, password: \u0027blah\u0027 }",
      "offset": 19
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5610277,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "invalid_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4280736,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 6394489,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 442055993,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 464459,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5462867,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 15015780,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 41437019,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9595035,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 12338572,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 9564884,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4948228,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 5840360,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4010699,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4177111,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 27107340,
  "status": "passed"
});
formatter.scenario({
  "line": 103,
  "name": "Validate 401 when a User making the request is Invalid",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 92,
  "name": "def invalid_user \u003d call basicAuth { username: \u0027dummy\u0027, password: \u0027blah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 93,
  "name": "header Authorization \u003d invalid_user",
  "keyword": "And "
});
formatter.step({
  "line": 94,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 95,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 96,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 97,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 98,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "invalid_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027dummy\u0027, password: \u0027blah\u0027 }",
      "offset": 19
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4697031,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "invalid_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 7837775,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 15478584,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 601582016,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 101330,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 12176851,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5731150,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 42053120,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 13929742,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 16254214,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 24383468,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2686538,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 7878306,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3419868,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3771470,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 34720256,
  "status": "passed"
});
formatter.scenario({
  "line": 104,
  "name": "Validate 401 when a User making the request is Invalid",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-a-user-making-the-request-is-invalid;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 92,
  "name": "def invalid_user \u003d call basicAuth { username: \u0027dummy\u0027, password: \u0027blah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 93,
  "name": "header Authorization \u003d invalid_user",
  "keyword": "And "
});
formatter.step({
  "line": 94,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 95,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 96,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 97,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 98,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "invalid_user",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027dummy\u0027, password: \u0027blah\u0027 }",
      "offset": 19
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3587611,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "invalid_user",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 2817310,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 2574938,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 155998311,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 100195,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 17085405,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 10058374,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 106,
  "name": "Validate 401 when username is correct but password is incorrect",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 107,
  "name": "def valid_user_invalid_password \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027blahblah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 108,
  "name": "header Authorization \u003d valid_user_invalid_password",
  "keyword": "And "
});
formatter.step({
  "line": 109,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 110,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 111,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 112,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 113,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 115,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 116,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 117,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 118,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 119,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 26558489,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 16984499,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 21499267,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 6351115,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6893026,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 19379116,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4702119,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 14957977,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 52282014,
  "status": "passed"
});
formatter.scenario({
  "line": 117,
  "name": "Validate 401 when username is correct but password is incorrect",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 107,
  "name": "def valid_user_invalid_password \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027blahblah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 108,
  "name": "header Authorization \u003d valid_user_invalid_password",
  "keyword": "And "
});
formatter.step({
  "line": 109,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 110,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 111,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 112,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 113,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "valid_user_invalid_password",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027blahblah\u0027 }",
      "offset": 34
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9556989,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "valid_user_invalid_password",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 15018126,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 6141359,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 444533195,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 62733,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5491701,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5611986,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 17819373,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 13272305,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 15358928,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 11263296,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4075746,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3292355,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4836462,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3326780,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 22108287,
  "status": "passed"
});
formatter.scenario({
  "line": 118,
  "name": "Validate 401 when username is correct but password is incorrect",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 107,
  "name": "def valid_user_invalid_password \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027blahblah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 108,
  "name": "header Authorization \u003d valid_user_invalid_password",
  "keyword": "And "
});
formatter.step({
  "line": 109,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 110,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 111,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 112,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 113,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "valid_user_invalid_password",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027blahblah\u0027 }",
      "offset": 34
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3213137,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "valid_user_invalid_password",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 6077755,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 3620240,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 572520491,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 63578,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4047085,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 13521780,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 19339299,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11260026,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 19394588,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 4313498,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3378018,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2756176,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3180891,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2676067,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 17160005,
  "status": "passed"
});
formatter.scenario({
  "line": 119,
  "name": "Validate 401 when username is correct but password is incorrect",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-correct-but-password-is-incorrect;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 107,
  "name": "def valid_user_invalid_password \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027blahblah\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 108,
  "name": "header Authorization \u003d valid_user_invalid_password",
  "keyword": "And "
});
formatter.step({
  "line": 109,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 110,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 111,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 112,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 113,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "valid_user_invalid_password",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027blahblah\u0027 }",
      "offset": 34
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 7182109,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "valid_user_invalid_password",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 2754743,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 3785600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 322553624,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 69169,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 6620925,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 5870931,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 121,
  "name": "Validate 401 when username is incorrect but password is correct",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 122,
  "name": "def invalid_user_valid_password \u003d call basicAuth { username: \u0027someone\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 123,
  "name": "header Authorization \u003d invalid_user_valid_password",
  "keyword": "And "
});
formatter.step({
  "line": 124,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 125,
  "name": "method \u003cmethod\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 126,
  "name": "status \u003cstatus\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 127,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 128,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 130,
  "name": "",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;",
  "rows": [
    {
      "cells": [
        "method",
        "status"
      ],
      "line": 131,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;;1"
    },
    {
      "cells": [
        "GET",
        "401"
      ],
      "line": 132,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;;2"
    },
    {
      "cells": [
        "POST",
        "401"
      ],
      "line": 133,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;;3"
    },
    {
      "cells": [
        "DELETE",
        "401"
      ],
      "line": 134,
      "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 27450341,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 7729690,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 11562280,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 4153074,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3184180,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3486575,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4103411,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3948498,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 17031933,
  "status": "passed"
});
formatter.scenario({
  "line": 132,
  "name": "Validate 401 when username is incorrect but password is correct",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 122,
  "name": "def invalid_user_valid_password \u003d call basicAuth { username: \u0027someone\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 123,
  "name": "header Authorization \u003d invalid_user_valid_password",
  "keyword": "And "
});
formatter.step({
  "line": 124,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 125,
  "name": "method GET",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 126,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 127,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 128,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "invalid_user_valid_password",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027someone\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 34
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 6339243,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "invalid_user_valid_password",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4807687,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 5305900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "GET",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 114148697,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 59030,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 3797573,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4206408,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 17236519,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 7660332,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 7446626,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 4321759,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2845537,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2115734,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3834911,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 3791256,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 15033791,
  "status": "passed"
});
formatter.scenario({
  "line": 133,
  "name": "Validate 401 when username is incorrect but password is correct",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 122,
  "name": "def invalid_user_valid_password \u003d call basicAuth { username: \u0027someone\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 123,
  "name": "header Authorization \u003d invalid_user_valid_password",
  "keyword": "And "
});
formatter.step({
  "line": 124,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 125,
  "name": "method POST",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 126,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 127,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 128,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "invalid_user_valid_password",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027someone\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 34
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2608712,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "invalid_user_valid_password",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 2573085,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 2031647,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "POST",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 117011301,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 61462,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 3732966,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4455491,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "# Configuration"
    }
  ],
  "line": 7,
  "name": "url \u0027https://qa106.aconex.com/api/document-relationships\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 8,
  "name": "def basicAuth \u003d read (\u0027classpath:sign-in.js\u0027)",
  "keyword": "* "
});
formatter.step({
  "line": 9,
  "name": "def poleary \u003d call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "* "
});
formatter.step({
  "line": 10,
  "name": "configure headers \u003d read(\u0027classpath:default-headers.json\u0027)",
  "keyword": "* "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "# Global Vars"
    }
  ],
  "line": 13,
  "name": "def project_id \u003d  \u00271879048454\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 14,
  "name": "def source_doc_id \u003d \u0027271341877549174248\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 15,
  "name": "def target_doc_id \u003d \u0027271341877549174268\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 16,
  "name": "def has_deviation_of \u003d \u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
  "keyword": "* "
});
formatter.step({
  "line": 18,
  "name": "path \u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027https://qa106.aconex.com/api/document-relationships\u0027",
      "offset": 4
    }
  ],
  "location": "StepDefs.url(String)"
});
formatter.result({
  "duration": 19027956,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "basicAuth",
      "offset": 4
    },
    {
      "val": "read (\u0027classpath:sign-in.js\u0027)",
      "offset": 16
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4421086,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poleary",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027poleary\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 14
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9784740,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "headers",
      "offset": 10
    },
    {
      "val": "read(\u0027classpath:default-headers.json\u0027)",
      "offset": 20
    }
  ],
  "location": "StepDefs.configure(String,String)"
});
formatter.result({
  "duration": 4843337,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "project_id",
      "offset": 4
    },
    {
      "val": " \u00271879048454\u0027",
      "offset": 17
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2621471,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "source_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174248\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 9115233,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "target_doc_id",
      "offset": 4
    },
    {
      "val": "\u0027271341877549174268\u0027",
      "offset": 20
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 2935593,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "has_deviation_of",
      "offset": 4
    },
    {
      "val": "\u0027819cad43-0838-47f3-b4a3-e977fb1d0dfe\u0027",
      "offset": 23
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 4847334,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027projects\u0027, project_id, \u0027documents\u0027, source_doc_id , \u0027relationships\u0027",
      "offset": 5
    }
  ],
  "location": "StepDefs.path(String\u003e)"
});
formatter.result({
  "duration": 18661509,
  "status": "passed"
});
formatter.scenario({
  "line": 134,
  "name": "Validate 401 when username is incorrect but password is correct",
  "description": "",
  "id": "handle-all-the-doc-linking-api-cases-that-result-in-http-401---unauthorised;validate-401-when-username-is-incorrect-but-password-is-correct;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 122,
  "name": "def invalid_user_valid_password \u003d call basicAuth { username: \u0027someone\u0027, password: \u0027ac0n3x72\u0027 }",
  "keyword": "Given "
});
formatter.step({
  "line": 123,
  "name": "header Authorization \u003d invalid_user_valid_password",
  "keyword": "And "
});
formatter.step({
  "line": 124,
  "name": "request \u0027\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 125,
  "name": "method DELETE",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 126,
  "name": "status 401",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 127,
  "name": "match /Error/ErrorCode \u003d\u003d \u0027UNAUTHORIZED\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 128,
  "name": "match /Error/ErrorDescription \u003d\u003d \u0027Invalid credentials\u0027",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "invalid_user_valid_password",
      "offset": 4
    },
    {
      "val": "call basicAuth { username: \u0027someone\u0027, password: \u0027ac0n3x72\u0027 }",
      "offset": 34
    }
  ],
  "location": "StepDefs.def(String,String)"
});
formatter.result({
  "duration": 8731723,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Authorization",
      "offset": 7
    },
    {
      "val": "invalid_user_valid_password",
      "offset": 23
    }
  ],
  "location": "StepDefs.header(String,String)"
});
formatter.result({
  "duration": 4476308,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u0027\u0027",
      "offset": 8
    }
  ],
  "location": "StepDefs.request(String)"
});
formatter.result({
  "duration": 3902077,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DELETE",
      "offset": 7
    }
  ],
  "location": "StepDefs.method(String)"
});
formatter.result({
  "duration": 667705318,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "401",
      "offset": 7
    }
  ],
  "location": "StepDefs.status(int)"
});
formatter.result({
  "duration": 96030,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorCode",
      "offset": 6
    },
    {},
    {
      "val": "\u0027UNAUTHORIZED\u0027",
      "offset": 26
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 4956879,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {},
    {
      "val": "/Error/ErrorDescription",
      "offset": 6
    },
    {},
    {
      "val": "\u0027Invalid credentials\u0027",
      "offset": 33
    }
  ],
  "location": "StepDefs.matchEquals(String,String,String,String)"
});
formatter.result({
  "duration": 8493298,
  "status": "passed"
});
});